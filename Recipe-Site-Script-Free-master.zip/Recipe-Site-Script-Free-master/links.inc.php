<?php
// copy the following line without the // for each link. Replace the url and url title for your friends links
// - <a href="http://www.arwscripts.com" target="_blank">Full Website Scripts</a><br>
?>
- <a href="http://www.a1hostweb.com" target="_blank">Cheap Web Hosting</a><br>
- <a href="http://www.arwscripts.com" target="_blank">Full Website Scripts</a><br>