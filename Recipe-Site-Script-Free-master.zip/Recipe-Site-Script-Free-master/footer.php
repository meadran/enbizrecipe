<tr>
	<td>
		<table width="770"  border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td valign="top" style="padding-top:11px " align="center">
				Copyright &copy; <?php echo date("Y"); ?> <a href="http://www.<?php echo $site_url; ?>" style="color:#C31B1B"><?php echo $site_url; ?></a> - Developed by <a href="http://www.arwscripts.com" style="color:#C31B1B">ARW Scripts</a><br>Use of this website is subject to our <a href="terms.html"  style="color:#C31B1B">Terms and Conditions.</a><br>All service marks, logos and trademarks belong to their respective owners
			<br>
<br></td>
		</tr>
		
		</table>
	</td>
</tr>
</table>
</BODY>
</HTML>
