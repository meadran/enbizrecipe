						<table width="160" height="100%"  border="0" cellspacing="0" cellpadding="0" background="http://<?php echo $site_url; ?>/images/back-text-1.jpg">
						<tr><td height="23" background="http://<?php echo $site_url; ?>/images/1-back-text-1.jpg" style="background-repeat:no-repeat;background-position:top;color:#FFFFFF" align="center"><span class="style1">CATEGORIES</span></td>
						</tr>
						<tr>
							<td style="padding-top:10px;padding-left:8px;line-height:15px;padding-bottom:15px "> 
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/browse.html">Category Listing</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/atoz.html">A to Z Listing</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-appetizers.html">Appetizers</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-Barbecue.html">Barbecue</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-low%20fat.html">Low Fat</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-children's.html">Childrens Recipes</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-Sandwiches.html">Sandwiches</a><br><img src="images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-homemade.html">Homemade</a><br><img src="images/spacer.gif" width="1" height="5"><br>
																<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/c-desserts.html">Desserts</a><br>
							</td>
						</tr>
						<tr><td bgcolor="#727272"><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="1"></td></tr>
						<tr><td bgcolor="#FFFFFF"><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="6"></td></tr>
						<tr><td height="23" background="http://<?php echo $site_url; ?>/images/1-back-text-1.jpg" style="background-repeat:no-repeat;background-position:top;color:#FFFFFF;padding-top:2px" align="center"><strong>RECOMMENDED RECIPES</strong></td>
						</tr>
						<tr>
							<td style="padding-top:11px;padding-left:8px;line-height:15px;padding-bottom:14px "> 
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/27199-recipe-buffalo-wings.html"><strong>NEW!</strong> Buffalo Wings</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/21897-recipe-California-Pizza.html"><strong>NEW!</strong> California Pizza</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/19464-recipe-Farm-House-Meatloaf.html">Meatloaf</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/19341-recipe-meatless-lasagna.html">Meatless Lasagna</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/24650-recipe-beef-stew.html">Beef Stew</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/773-recipe-alfredo-sauce.html">Alfredo Sauce</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/12746-recipe-Chicken-Curry.html">Chicken Curry</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/29599-recipe-crab-quiche.html">Crab Quiche</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/16031-recipe-barbecued-salmon.html">Barbecued Salmon</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/13277-recipe-apple-slices.html">Apple Slices</a>																																	
							</td>
						</tr>
						<tr><td bgcolor="#727272"><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="1"></td></tr>
						<tr><td bgcolor="#FFFFFF"><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="6"></td></tr>
						<tr><td height="23" background="http://<?php echo $site_url; ?>/images/1-back-text-1.jpg" style="background-repeat:no-repeat;background-position:top;color:#FFFFFF;padding-top:2px" align="center"><strong>SITE INFORMATION</strong></td>
						</tr>
						<tr>
							<td height="100%" valign="top" style="padding-top:12px;padding-left:8px;line-height:15px;padding-bottom:13px "> 
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/about-us.html">About Us</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/contact-us.html">Contact Us</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/friends.html">Friends of <?php echo $site_name; ?></a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>	
								<img src="http://<?php echo $site_url; ?>/images/b-5.gif" width="3" height="5" align="absmiddle" style="margin-right:6px"><a href="http://<?php echo $site_url; ?>/terms.html">Site Terms</a><br><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="5"><br>	
							</td>
						</tr>
						<tr><td bgcolor="#727272"><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="1"></td></tr>
						<tr><td bgcolor="#FFFFFF"><img src="http://<?php echo $site_url; ?>/images/spacer.gif" width="1" height="8"></td></tr>
						</table>