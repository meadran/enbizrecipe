<?php

// this is your unique licence key for your purchase. This permits usage on one domain name and can not be replicated or distibuted without express permission from arwscripts.com.

$licence_key = "";

?>